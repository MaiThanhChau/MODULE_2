<?php
interface Resizeable{
    public function resize($name,$newSize);
}