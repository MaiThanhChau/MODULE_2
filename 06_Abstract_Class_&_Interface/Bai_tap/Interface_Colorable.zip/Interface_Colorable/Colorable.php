<?php
interface Colorable{
    public function howtoColor();      
}